import Foot from "./Foot";

export {
    Foot,
};