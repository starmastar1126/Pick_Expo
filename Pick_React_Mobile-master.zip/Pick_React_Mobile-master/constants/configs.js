export default {
    baseURL: "http://xxxxx.com/",
    jsonURL: "http://xxxxx.com/api/",
    dataURL: "http://xxxxx.com/storage/data/",
}