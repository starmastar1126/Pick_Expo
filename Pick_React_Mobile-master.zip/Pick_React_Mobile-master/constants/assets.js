export const images = {
    car: require("@assets/ferrari.jpeg"),
    lock_car: require("@assets/lock_car.png"),
    host: require("@assets/host.png"),
    congratulation: require("@assets/congratulation.png"),
    person1: require("@assets/person1.jpg"),
    person2: require("@assets/person2.jpg"),
    person3: require("@assets/person3.jpg"),
    person4: require("@assets/person4.jpg"),
    person5: require("@assets/person5.jpg"),
    seat: require("@assets/seat.png"),
    map: require("@assets/map.png"),
    visa: require("@assets/visa.png"),
}

export const icons = {
    // app_icon: require("@assets/icon.png"),
}