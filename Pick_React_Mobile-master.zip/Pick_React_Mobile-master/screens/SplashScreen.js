import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  TouchableOpacity,
  Dimensions,
  Image,
} from "react-native";
import SignInScreen from "./SignInScreen";
//
/**
 * @author
 * @function SplashScreen
 **/
const SplashScreen = ({ navigation }) => {
  const [isVisible, setIsVisible] = React.useState(true);
  const Hide_Splash_Screen = () => {
    setIsVisible(false);
  };

  React.useEffect(() => {
    setTimeout(() => {
      Hide_Splash_Screen();
    }, 10000);
  }, []);

  return isVisible ? (
    <View style={styles.container}>
      <Image
        source={require("../assets/Splash-Gif.gif")}
        style={styles.backgroundImage}
      />
    </View>
  ) : (
    <SignInScreen navigation={navigation} />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "black",
    // borderColor: 'white',
    // borderWidth: 1
  },
  backgroundImage: {
    flex: 1,
    resizeMode: "cover", // or 'stretch',
    justifyContent: "center",
    alignSelf: "center",
  },
});

export default SplashScreen;
