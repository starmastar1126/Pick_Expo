import React from "react";
import { StyleSheet, Text, View, ScrollView, Image } from "react-native";
import { Container, Content, Item, Input } from "native-base";
import { SimpleLineIcons } from "@expo/vector-icons";

import Categoryheader from "../components/Categoryheader";
import Carcard from "../components/Carcard";
import Tophost from "../components/Tophost";
import Destination from "../components/Destination";
import Earningcard from "../components/Earningcard";
import Heading from "../components/Heading";
import Foot from "../components/Foot";
import { connect } from "react-redux";

class MainScreen extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { users } = this.props;
    if (!users[0]) {
      this.props.navigation.navigate("SignInScreen");
    }
    console.log(users);
  }
  render() {
    return (
      <Container>
        <Heading
          onMessage={() => this.props.navigation.navigate("MessageScreen")}
          onProfile={() => this.props.navigation.navigate("DriverScreen")}
        />
        <Content>
          <ScrollView>
            <View style={styles.searchSection}>
              <Item rounded style={styles.searchbox}>
                <Input
                  placeholder="Location, place or category"
                  style={styles.searchtxt}
                  onFocus={() => this.props.navigation.navigate("SearchScreen")}
                />
                <SimpleLineIcons
                  name="magnifier"
                  size={20}
                  color="black"
                  style={styles.searchicon}
                />
              </Item>
            </View>
            <View style={styles.Category}>
              <Categoryheader head1="Popular" head2="Cars" />
            </View>
            <View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={{ flexDirection: "row" }}>
                  <Carcard />
                  <Carcard />
                  <Carcard />
                </View>
              </ScrollView>
            </View>

            <View style={styles.Category}>
              <Categoryheader head1="Top" head2="Host" />
            </View>
            <View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <Tophost />
                <Tophost />
                <Tophost />
              </ScrollView>
            </View>

            <View style={[styles.Category, { marginTop: 10 }]}>
              <Categoryheader head1="Today's" head2="Feed" />
            </View>

            <View>
              <Image
                source={require("@assets/car.jpg")}
                style={styles.carImage}
                resizeMode="stretch"
              />
              <Text style={styles.cartext}>Ferrari New Launch 2020</Text>
              <Text style={styles.cartext2}>Ferrari New Launch 2020</Text>
            </View>

            <View style={[styles.Category, { marginTop: 10 }]}>
              <Categoryheader head1="Popular" head2="Destination" />
            </View>
            <View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <Destination />
                <Destination />
                <Destination />
              </ScrollView>
            </View>

            <View style={[styles.Category, { marginTop: 10 }]}>
              <Categoryheader head1="Start earning " head2="today" />
            </View>
            <View>
              <Earningcard />
            </View>

            <View style={[styles.Category, { marginTop: 10 }]}>
              <Categoryheader head1="Go for " head2="ride" />
            </View>
            <View>
              <Earningcard />
            </View>
          </ScrollView>
        </Content>
        <Foot selected="Main" navigation={this.props.navigation} />
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    users: state,
  };
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(MainScreen);

const styles = StyleSheet.create({
  searchbox: {
    marginHorizontal: 20,
    marginLeft: 18,
  },
  searchicon: {
    marginRight: 10,
  },
  searchtxt: {
    marginLeft: 10,
    fontSize: 15,
    width: "100%",
  },
  Category: {
    marginVertical: 10,
  },
  cartext: {
    position: "absolute",
    color: "white",
    marginLeft: 30,
    marginTop: 10,
    fontSize: 18,
    fontWeight: "bold",
  },
  cartext2: {
    position: "absolute",
    color: "white",
    marginLeft: 30,
    marginTop: 35,
    fontSize: 12,
    fontWeight: "400",
  },
  carImage: {
    width: "95%",
    height: 150,
    borderRadius: 10,
    marginLeft: 10,
    marginRight: 10,
  },
  searchSection: {
    marginHorizontal: 20,
  },
  searchbox: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
    padding: 15,
    width: "100%",
    height: 50,
    justifyContent: "space-between",
    marginHorizontal: 20,
  },
});
