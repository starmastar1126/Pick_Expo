const Users = (state = [], action) => {
  switch (action.type) {
    case "SIGN_IN":
      return [...state, action.payload];

    case "SIGN_OUT":
      return state.filter((cartItem) => cartItem.id !== action.payload.id);
  }
  return state;
};

export default Users;
