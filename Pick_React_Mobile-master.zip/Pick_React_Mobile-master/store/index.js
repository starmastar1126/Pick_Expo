import { createStore } from "redux";
import Users from "../reducer/User";

export default store = createStore(Users);
